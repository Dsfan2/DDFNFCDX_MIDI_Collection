All the songs and their vocal tracks were made in LMMS, and unfortunately, when exporting MIDI it didn't include any of the automations.
So you're gonna have to do the audio effects and automations yourself.
Only 4 song include automations.
Hxppy Thxughts, Cxnnamon Bxn, & Yandere have pitch down automation.
Pale has BPM change automation (BPM increases by 5 every time the song key changes. First change is 165, last change is 280)

Glitchsuki, Sayorivil, and Monika NEO are the only characters that use audio effects